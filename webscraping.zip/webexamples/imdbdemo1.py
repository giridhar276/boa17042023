import requests
from bs4 import BeautifulSoup
html = "https://www.imdb.com/chart/moviemeter/?ref_=nv_mv_mpm"
request = requests.get(html)



soup = BeautifulSoup(request.text,"html.parser")
movies = soup.find('tbody', class_="lister-list").find_all('tr')


for movie in movies:
    moviename = movie.find('td',class_ = 'titleColumn').a.text
    print("Movie :",moviename)
    year = movie.find('td', class_="titleColumn").span.text.strip('()')
    print("Year :", year)
    print("-------")
    