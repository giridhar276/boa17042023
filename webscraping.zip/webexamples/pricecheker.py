import requests
from bs4 import BeautifulSoup
import smtplib


url = "https://www.amazon.in/Apple-AirPods-Pro-2nd-Generation/dp/B0BDKD8DVD/ref=sr_1_2?adgrpid=60812105023&ext_vrnc=hi&hvadid=590678986248&hvdev=c&hvlocphy=9062136&hvnetw=g&hvqmt=b&hvrand=2709624938119879539&hvtargid=kwd-1646976446830&hydadcr=18813_2250395&keywords=apple+air-pods+2nd+generation&qid=1681756843&sr=8-2"
headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36"}

price_value = 1270000

email_address  = "giridharsofficial@gmail.com"
password = "hujjlhcbxwjjxurc"
receiver_email = "giridharsofficial@gmail.com"

def getPrice():
    page = requests.get(url,headers = headers)
    soup = BeautifulSoup(page.content,"html.parser")
    title = soup.find(id='productTitle').get_text()
    #price = soup.find(id = 'priceblock_ourprice').get_text().strip()
    price = soup.select_one("span[class='a-offscreen']").text
    
    #//*[@id="corePriceDisplay_desktop_feature_div"]/div[1]/span[1]/span[2]/span[2]
    print(title)
    print(price)
    return price


def trackPrices():
    output = getPrice()
    output = output.replace('₹','')
    output = output.replace(',','')
    print('test',output)
    price  = float(output)
    print(price)
    if price  > price_value:
        diff = int(price - price_value)
        print('still too expensive')
    else:
        print('nofity me')
        sendEmail()
        
def sendEmail():
    
    subject = 'Amazon price has dropped'
    mailtext = 'subject:' + subject + '\n\n' + url
    server = smtplib.SMTP(host = 'smtp.gmail.com', port =587)
    server.ehlo()
    server.starttls()
    server.login(email_address,password)
    server.sendmail(email_address,receiver_email,mailtext)    



if __name__ == "__main__":
    #print(getPrice())
    trackPrices()






